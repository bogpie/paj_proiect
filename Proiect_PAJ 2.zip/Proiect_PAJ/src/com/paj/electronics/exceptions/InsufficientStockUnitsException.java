package com.paj.electronics.exceptions;

public class InsufficientStockUnitsException extends Exception {
  public InsufficientStockUnitsException(String message) {
    super(message);
  }
}
