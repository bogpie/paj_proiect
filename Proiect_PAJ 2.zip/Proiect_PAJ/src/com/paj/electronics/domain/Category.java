package com.paj.electronics.domain;

public enum Category {
  LAPTOP, MOBILE, PC_COMPONENTS, GAMING, MONITORS, PERIPHERALS;
}
