package com.paj.electronics.domain;

public enum Color {
  BLACK, BLUE, RED, GREEN;
}
