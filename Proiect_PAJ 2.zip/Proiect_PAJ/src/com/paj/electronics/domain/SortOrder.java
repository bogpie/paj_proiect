package com.paj.electronics.domain;

public enum SortOrder {
  ASCENDING, DESCENDING
}
