package com.paj.electronics.domain;

public enum UserType {
  CLIENT, SUPPLIER
}
