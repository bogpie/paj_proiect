package com.paj.electronics.domain;

public enum OrderStatus {
  CREATED, CANCELLED, PROCESSING, SHIPPING, DELIVERED;
}
