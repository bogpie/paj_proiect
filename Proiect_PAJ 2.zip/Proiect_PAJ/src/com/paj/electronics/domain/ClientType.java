package com.paj.electronics.domain;

public enum ClientType {
  NORMAL, PREMIUM
}
